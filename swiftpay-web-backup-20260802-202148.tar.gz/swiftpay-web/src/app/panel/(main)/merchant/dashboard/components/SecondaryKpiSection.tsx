'use client';

import { CancelCircleIcon, CheckmarkCircle02Icon, MoneyExchange01Icon } from '@hugeicons/core-free-icons';
import { KpiCard } from '../DashboardCards';
import { AnimatedCurrency } from '@/components/ui/animated-currency';
import { AnimatedNumber } from '@/components/ui/animated-number';
import type { MerchantKpiData, DashboardCacheInfo } from '@/types/merchant/dashboard';

interface SecondaryKpiSectionProps {
	kpis: MerchantKpiData;
	cacheInfo: DashboardCacheInfo;
	isBalanceVisible: boolean;
}

export function SecondaryKpiSection({ kpis, cacheInfo, isBalanceVisible }: SecondaryKpiSectionProps) {
	const valueClassName = isBalanceVisible ? '' : 'visual-blur';

	return (
		<div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
			<KpiCard
				icon={CheckmarkCircle02Icon}
				iconColor="var(--accent)"
				contentClassName="min-h-22 gap-1.5! p-3!"
				label="Transações OK"
				tooltip="Quantidade de transações aprovadas no período filtrado."
				value={
					<div className="flex items-baseline gap-2 whitespace-nowrap">
						<span className={`${valueClassName}`}>{kpis.completedTransactions}</span>
						<span className={`text-xs ${valueClassName}`} style={{ color: 'var(--text-muted)' }}>de {kpis.totalTransactions}</span>
					</div>
				}
				growth={kpis.transactionsGrowth}
				growthComparisonLabel={kpis.growthComparisonLabel}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={MoneyExchange01Icon}
				iconColor="var(--brand)"
				contentClassName="min-h-22 gap-1.5! p-3!"
				label="Total Sacado"
				tooltip="Valor total de saques concluídos no período filtrado."
				value={<AnimatedCurrency value={kpis.totalPayouts} className={`${valueClassName}`} />}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={CancelCircleIcon}
				iconColor="#ef4444"
				contentClassName="min-h-22 gap-1.5! p-3!"
				label="Falhas"
				tooltip="Quantidade de transações com falha no período e taxa de falha."
				value={
					<div className="flex items-baseline gap-1 whitespace-nowrap">
						<span className={`${valueClassName}`}>{kpis.failedTransactions}</span>
						<span className={`text-xs ${valueClassName}`} style={{ color: 'var(--text-muted)' }}>
							(<AnimatedNumber value={kpis.failedRate} suffix="%" maximumFractionDigits={1} />)
						</span>
					</div>
				}
				growth={kpis.failedRateGrowth}
				growthComparisonLabel={kpis.growthComparisonLabel}
				invertColors
				isProcessing={cacheInfo.isProcessing}
			/>
		</div>
	);
}
