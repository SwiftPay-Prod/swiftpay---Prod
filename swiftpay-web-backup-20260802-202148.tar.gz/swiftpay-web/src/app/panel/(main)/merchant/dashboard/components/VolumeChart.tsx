'use client';

import { Bar, BarChart, CartesianGrid, XAxis } from 'recharts';
import { Analytics02Icon, InformationCircleIcon } from '@hugeicons/core-free-icons';
import { Icon } from '@/components/ui/icon';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { formatCurrency } from '@/utils/currency';
import type { MerchantDailyVolumeData, MerchantWeeklyVolumeData } from '@/types/merchant/dashboard';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const volumeChartConfig = {
  volume: {
    label: 'Volume',
    color: 'hsl(var(--primary))',
  },
} satisfies ChartConfig;

interface VolumeChartProps {
  data: MerchantDailyVolumeData[];
  adaptiveData: MerchantWeeklyVolumeData[];
  isHourlyGranularity: boolean;
  isProcessing?: boolean;
  periodLabel?: string;
}

export function VolumeChart({ data, adaptiveData, isHourlyGranularity, isProcessing, periodLabel }: VolumeChartProps) {
  const chartData = isHourlyGranularity
    ? adaptiveData.map((item) => ({
        date: item.label,
        volume: item.volume,
        transactionCount: item.transactionCount,
      }))
    : data.map((item) => ({
        date: new Date(item.date).toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit' }),
        volume: item.volume,
        transactionCount: item.transactionCount,
      }));

  return (
    <div className={`rounded-lg border bg-card text-card-foreground shadow-xs ${isProcessing ? 'opacity-70' : ''}`}>
      <div className="flex flex-col space-y-1.5 p-4 pb-0">
        <div className="flex items-center gap-2 text-sm font-medium leading-none">
          <Icon icon={Analytics02Icon} className="icon-sm text-primary" />
          {isHourlyGranularity ? 'Volume por hora' : 'Volume diário'}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger className="inline-flex cursor-help">
                <Icon icon={InformationCircleIcon} className="icon-xs text-muted-foreground opacity-60" />
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-64 text-xs">
                Mostra quanto você recebeu por dia. Cada barra representa o total de um dia. Passe o mouse sobre as barras para
                ver os valores.
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          {isProcessing && <div className="ml-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />}
        </div>
        <p className="text-xs text-muted-foreground">{periodLabel || 'Últimos 7 dias'}</p>
      </div>
      <div className="p-4 pt-0">
        <ChartContainer config={volumeChartConfig} className="h-32 w-full">
          <BarChart accessibilityLayer data={chartData}>
            <CartesianGrid vertical={false} strokeDasharray="3 3" className="stroke-border/50" />
            <XAxis dataKey="date" tickLine={false} tickMargin={6} axisLine={false} fontSize={9} />
            <ChartTooltip
              content={
                <ChartTooltipContent
                  formatter={(value, name) =>
                    name === 'volume' ? formatCurrency(value as number) : `${value} transações`
                  }
                />
              }
            />
            <Bar dataKey="volume" fill="var(--color-volume)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </div>
    </div>
  );
}
