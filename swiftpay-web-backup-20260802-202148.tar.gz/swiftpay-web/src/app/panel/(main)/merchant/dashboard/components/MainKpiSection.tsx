'use client';

import {
	Alert01Icon,
	AnalyticsUpIcon,
	ArrowReloadHorizontalIcon,
	MoneyExchange01Icon,
	MoneyReceiveSquareIcon,
	TransactionHistoryIcon,
	Wallet01Icon,
} from '@hugeicons/core-free-icons';
import { KpiCard } from '../DashboardCards';
import { AnimatedCurrency } from '@/components/ui/animated-currency';
import { AnimatedNumber } from '@/components/ui/animated-number';
import type { MerchantKpiData, MerchantBalanceData, DashboardCacheInfo } from '@/types/merchant/dashboard';

interface MainKpiSectionProps {
	kpis: MerchantKpiData;
	balance: MerchantBalanceData;
	cacheInfo: DashboardCacheInfo;
	averageTicket: number;
	isBalanceVisible: boolean;
	hasReserveEnabled: boolean;
	reserveConfig: {
		pixReservePercentage: number;
		boletoReservePercentage: number;
		creditCardReservePercentage: number;
	} | null;
}

function formatReservePercentage(basisPoints: number): string {
	return `${(basisPoints / 100).toFixed(2)}%`;
}

export function MainKpiSection({
	kpis,
	balance,
	cacheInfo,
	averageTicket,
	isBalanceVisible,
	hasReserveEnabled,
	reserveConfig,
}: MainKpiSectionProps) {
	const valueClassName = isBalanceVisible ? '' : 'visual-blur';
	const reserveSummary = reserveConfig
		? [
				`PIX ${formatReservePercentage(reserveConfig.pixReservePercentage)}`,
				`Boleto ${formatReservePercentage(reserveConfig.boletoReservePercentage)}`,
				`Cartão ${formatReservePercentage(reserveConfig.creditCardReservePercentage)}`,
		  ].join(' | ')
		: null;

	return (
		<div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
			<KpiCard
				icon={Wallet01Icon}
				iconColor="var(--accent)"
				label="Saldo Disponível"
				tooltip="Valor disponível para saque agora. Atualizado em tempo real."
				value={<AnimatedCurrency value={balance.available} className={`${valueClassName}`} />}
				isProcessing={false}
			/>
			<KpiCard
				icon={MoneyReceiveSquareIcon}
				iconColor="var(--accent)"
				label="Total de Vendas"
				tooltip="Total de vendas descontando as taxas da plataforma no período filtrado."
				value={<AnimatedCurrency value={kpis.totalNetVolume} className={`${valueClassName}`} />}
				growth={kpis.volumeGrowth}
				growthComparisonLabel={kpis.growthComparisonLabel}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={TransactionHistoryIcon}
				iconColor="#f59e0b"
				label="Vendas Pendentes"
				tooltip="Pagamentos ainda em processamento. Esses valores não estão disponíveis para saque ainda."
				value={<AnimatedCurrency value={balance.pending} className={`${valueClassName}`} />}
				isProcessing={cacheInfo.isProcessing}
			/>
			{hasReserveEnabled && (
				<KpiCard
					icon={Wallet01Icon}
					iconColor="var(--text-muted)"
					label="Saldo Reservado"
					tooltip={`Valor temporariamente retido pela reserva financeira das suas vendas. Esse montante continua sendo da organização e é transferido para o saldo disponível ao final do prazo de compensação configurado por método. ${reserveSummary ? `Configuração atual: ${reserveSummary}.` : ''}`}
					value={<AnimatedCurrency value={balance.reserved} className={`${valueClassName}`} />}
					isProcessing={cacheInfo.isProcessing}
				/>
			)}
			<KpiCard
				icon={AnalyticsUpIcon}
				iconColor="var(--brand)"
				label="Ticket Médio"
				tooltip="Valor médio de cada transação aprovada no período filtrado."
				value={<AnimatedCurrency value={averageTicket} className={`${valueClassName}`} />}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={MoneyExchange01Icon}
				iconColor="var(--accent)"
				label="Volume Bruto"
				tooltip="Somatório bruto de todos os pagamentos aprovados no período filtrado."
				value={<AnimatedCurrency value={kpis.totalVolume} className={`${valueClassName}`} />}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={ArrowReloadHorizontalIcon}
				iconColor="var(--text-muted)"
				label="Saque Pendente"
				tooltip="Total de saques solicitados que ainda não foram concluídos."
				value={<AnimatedCurrency value={kpis.pendingPayouts} className={`${valueClassName}`} />}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={Alert01Icon}
				iconColor="#f59e0b"
				label="Reembolso"
				tooltip="Valor total de estornos e reembolsos realizados no período filtrado."
				value={<AnimatedCurrency value={kpis.refundedAmount} className={`${valueClassName}`} />}
				isProcessing={cacheInfo.isProcessing}
			/>
			<KpiCard
				icon={Alert01Icon}
				iconColor="#ef4444"
				label="Chargeback"
				tooltip="Quantidade e percentual de disputas/chargebacks no período."
				value={
					<div className="flex items-baseline gap-2">
						<span className={`${valueClassName}`}>{kpis.chargebackCount}</span>
						<span className={`text-sm ${valueClassName}`} style={{ color: 'var(--text-muted)' }}>
							(<AnimatedNumber value={kpis.chargebackRate} suffix="%" maximumFractionDigits={1} />)
						</span>
					</div>
				}
				isProcessing={cacheInfo.isProcessing}
			/>
		</div>
	);
}
