'use client';

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  CancelCircleIcon,
  ChartDownIcon,
  ChartUpIcon,
  HelpCircleIcon,
  InformationCircleIcon,
  TransactionHistoryIcon,
  Wallet01Icon,
  Wallet03Icon,
} from '@hugeicons/core-free-icons';
import type { IconSvgElement } from '@hugeicons/react';
import { Icon } from '@/components/ui/icon';
import { AnimatedCurrency } from '@/components/ui/animated-currency';
import { AnimatedNumber } from '@/components/ui/animated-number';
import type { MerchantBalanceData } from '@/types/merchant/dashboard';

const BALANCE_TOOLTIPS = {
  available:
    'Valor liberado para saque. Esse é o saldo que você pode transferir para sua conta bancária a qualquer momento.',
  pending:
    'Valor de pagamentos criados e não pagos no período selecionado.',
  reserved:
    'Valor retido temporariamente para cobrir possíveis chargebacks, disputas ou garantias contratuais.',
  total: 'Soma dos pagamentos no período selecionado.',
};

function InfoTip({ content }: { content: string }) {
  return (
    <span
      className="inline-flex cursor-help shrink-0"
      title={content}
      style={{ color: 'var(--text-muted)' }}
    >
      <Icon icon={InformationCircleIcon} className="icon-xs" />
    </span>
  );
}

interface KpiCardProps {
  icon: IconSvgElement;
  iconColor?: string;
  cardClassName?: string;
  contentClassName?: string;
  isMain?: boolean;
  label: string;
  tooltip?: string;
  value: React.ReactNode;
  growth?: number | null;
  growthSuffix?: string;
  growthComparisonLabel?: string | null;
  invertColors?: boolean;
  isProcessing?: boolean;
}

export function KpiCard({
  icon,
  iconColor = 'text-primary',
  cardClassName,
  contentClassName,
  isMain = false,
  label,
  tooltip,
  value,
  growth,
  growthSuffix = '%',
  growthComparisonLabel,
  invertColors = false,
  isProcessing,
}: KpiCardProps) {
  const hasGrowth = growth !== null && growth !== undefined;
  const isPositive = hasGrowth && growth > 0;
  const isNegative = hasGrowth && growth < 0;

  const growthColor = invertColors
    ? isPositive
      ? 'color: var(--accent)'
      : isNegative
        ? 'color: #ef4444'
        : 'color: var(--text-muted)'
    : isPositive
      ? 'color: var(--accent)'
      : isNegative
        ? 'color: #ef4444'
        : 'color: var(--text-muted)';

  const GrowthIcon = isPositive ? ChartUpIcon : ChartDownIcon;

  return (
    <div
      className={`rounded-[var(--radius)] border ${isProcessing ? 'opacity-70' : ''}`}
      style={{
        backgroundColor: 'var(--card-bg)',
        borderColor: 'var(--border)',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--border-hover)'; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border)'; }}
    >
      <div className={`flex flex-col gap-2 p-4 ${contentClassName ?? ''}`}>
        <div className="flex min-w-0 items-center gap-2">
          <Icon icon={icon} className={`${iconColor} ${isMain ? 'icon-md' : 'icon-sm'} shrink-0`} />
          <span className="truncate text-[11px] font-bold uppercase tracking-[0.5px]" style={{ color: 'var(--text-muted)' }}>{label}</span>
          {tooltip && <InfoTip content={tooltip} />}
          {isProcessing && <div className="ml-auto shrink-0 h-4 w-4 animate-spin rounded-full border-2" style={{ borderColor: 'var(--brand)', borderTopColor: 'transparent' }} />}
        </div>
        <div className="min-w-0 leading-tight font-[family-name:var(--font-mono)] text-[26px] font-extrabold tracking-[-1px]" style={{ color: 'var(--text)' }}>{value}</div>
        {hasGrowth && growth !== 0 && (
          <span className="flex items-center gap-0.5 text-xs font-bold cursor-help" style={{ color: growthColor === 'color: var(--accent)' ? 'var(--accent)' : growthColor === 'color: #ef4444' ? '#ef4444' : 'var(--text-muted)' }}>
            <Icon icon={isPositive ? ChartUpIcon : ChartDownIcon} className="icon-xs" />
            <AnimatedNumber
              value={growth}
              prefix={isPositive ? '+' : undefined}
              suffix={growthSuffix}
              maximumFractionDigits={1}
            />
          </span>
        )}
      </div>
    </div>
  );
}

export function BalanceCards({ balance }: { balance: MerchantBalanceData }) {
  const cards = [
    {
      key: 'available',
      label: 'Disponível',
      value: balance.available,
      icon: Wallet01Icon,
      iconColor: 'var(--accent)',
      borderColor: 'var(--accent)',
      tooltip: BALANCE_TOOLTIPS.available,
    },
    {
      key: 'pending',
      label: 'Pendente',
      value: balance.pending,
      icon: TransactionHistoryIcon,
      iconColor: '#f59e0b',
      borderColor: '#f59e0b',
      tooltip: BALANCE_TOOLTIPS.pending,
    },
    {
      key: 'reserved',
      label: 'Saque pendente',
      value: balance.reserved,
      icon: CancelCircleIcon,
      iconColor: 'var(--text-muted)',
      borderColor: 'var(--border)',
      tooltip: BALANCE_TOOLTIPS.reserved,
    },
    {
      key: 'total',
      label: 'Total',
      value: balance.total,
      icon: Wallet03Icon,
      iconColor: 'var(--brand)',
      borderColor: 'var(--brand)',
      tooltip: BALANCE_TOOLTIPS.total,
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <div
          key={card.key}
          className="rounded-[var(--radius)]"
          style={{
            backgroundColor: 'var(--card-bg)',
            border: '1px solid var(--border)',
            borderLeft: `2px solid ${card.borderColor}`,
          }}
        >
          <div className="flex flex-col gap-2 p-4">
            <div className="flex items-center gap-2">
              <Icon icon={card.icon} className="icon-md shrink-0" style={{ color: card.iconColor }} />
              <span className="text-[11px] font-bold uppercase tracking-[0.5px]" style={{ color: 'var(--text-muted)' }}>{card.label}</span>
              <InfoTip content={card.tooltip} />
            </div>
            <span style={{ color: 'var(--text)' }}>
              <AnimatedCurrency value={card.value} className="font-[family-name:var(--font-mono)] text-2xl font-extrabold tracking-[-1px]" compact />
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
