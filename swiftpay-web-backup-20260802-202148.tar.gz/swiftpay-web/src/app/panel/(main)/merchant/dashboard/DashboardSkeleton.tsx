'use client';

import { Skeleton } from '@/components/ui/skeleton';

export function DashboardSkeleton() {
  return (
    <div className="flex flex-col gap-4">
      <div className="h-28 rounded-[var(--radius)]" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--border)' }}>
        <div className="p-4"><Skeleton className="h-20 w-full rounded-[var(--radius)]" /></div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Skeleton className="h-8 w-44 rounded-[var(--radius)]" />
        <div className="flex items-center gap-3">
          <Skeleton className="h-4 w-32 rounded-[var(--radius)]" />
          <Skeleton className="h-9 w-24 rounded-[var(--radius)]" />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="rounded-[var(--radius)] p-4 flex flex-col gap-2" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-2">
              <Skeleton className="h-5 w-5 rounded-[var(--radius)]" />
              <Skeleton className="h-4 w-20 rounded-[var(--radius)]" />
            </div>
            <Skeleton className="h-8 w-32 rounded-[var(--radius)]" />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="rounded-[var(--radius)] p-3 flex flex-col gap-1" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--border)' }}>
            <Skeleton className="h-3 w-16 rounded-[var(--radius)]" />
            <Skeleton className="h-5 w-24 rounded-[var(--radius)]" />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="rounded-[var(--radius)]" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--border)' }}>
            <div className="p-4 pb-0">
              <div className="flex items-center gap-2">
                <Skeleton className="h-4 w-4 rounded-[var(--radius)]" />
                <Skeleton className="h-4 w-28 rounded-[var(--radius)]" />
              </div>
              <Skeleton className="mt-1 h-3 w-20 rounded-[var(--radius)]" />
            </div>
            <div className="p-4">
              <Skeleton className="h-32 w-full rounded-[var(--radius)]" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
