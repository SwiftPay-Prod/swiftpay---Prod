'use client';

import { Cell, Pie, PieChart } from 'recharts';
import { CheckmarkCircle02Icon, InformationCircleIcon } from '@hugeicons/core-free-icons';
import { Icon } from '@/components/ui/icon';
import { AnimatedNumber } from '@/components/ui/animated-number';
import { approvalRateLevelParse } from '@/parse';
import { ApprovalRateLevel } from '@/types/enums';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const GAUGE_SEGMENTS = [
  { name: '0–15%', value: 15, color: '#d4d4d4' },
  { name: '15–25%', value: 10, color: '#a3a3a3' },
  { name: '25–35%', value: 10, color: '#737373' },
  { name: '35–50%', value: 15, color: '#404040' },
  { name: '50%+', value: 50, color: '#171717' },
];

const LEVEL_COLOR_MAP: Record<string, string> = {
  danger: 'text-destructive',
  warning: 'text-amber-500',
  default: 'text-amber-500',
  accent: 'text-primary',
  success: 'text-green-500',
};

const RADIAN = Math.PI / 180;

interface ApprovalRateGaugeProps {
  approvalRate: number;
  approvalRateLevel?: ApprovalRateLevel | null;
  isProcessing?: boolean;
  isBalanceVisible: boolean;
}

export function ApprovalRateGauge({ approvalRate, approvalRateLevel, isProcessing, isBalanceVisible }: ApprovalRateGaugeProps) {
  const cx = 100;
  const cy = 85;
  const innerRadius = 50;
  const outerRadius = 75;

  const ang = 180 - (Math.min(Math.max(approvalRate, 0), 100) / 100) * 180;
  const length = (innerRadius + outerRadius) / 2;
  const needleX = cx + length * Math.cos(-RADIAN * ang);
  const needleY = cy + length * Math.sin(-RADIAN * ang);

  const levelKey = approvalRateLevel ?? ApprovalRateLevel.Average;
  const levelParse = approvalRateLevelParse[levelKey] ?? approvalRateLevelParse[ApprovalRateLevel.Average];

  return (
    <div
      className={`rounded-[var(--radius)] ${isProcessing ? 'opacity-70' : ''}`}
      style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--border)' }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--border-hover)'; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border)'; }}
    >
      <div className="flex flex-col space-y-1.5 p-4 pb-0">
        <div className="flex items-center gap-2 text-sm leading-none">
          <Icon icon={CheckmarkCircle02Icon} className="icon-sm" style={{ color: 'var(--accent)' }} />
          <span className="text-[13px] font-bold uppercase tracking-[0.5px]" style={{ color: 'var(--text)' }}>Taxa de Conversão</span>
          {isProcessing && <div className="ml-2 h-4 w-4 animate-spin rounded-full border-2" style={{ borderColor: 'var(--brand)', borderTopColor: 'transparent' }} />}
        </div>
        <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>Desempenho dos pagamentos</p>
      </div>
      <div className="flex flex-col items-center p-4 pt-2">
        <PieChart width={200} height={110}>
          <Pie
            data={GAUGE_SEGMENTS}
            cx={cx}
            cy={cy}
            startAngle={180}
            endAngle={0}
            innerRadius={innerRadius}
            outerRadius={outerRadius}
            dataKey="value"
            stroke="none"
          >
            {GAUGE_SEGMENTS.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <g>
            <circle cx={cx} cy={cy} r={4} fill="var(--accent)" />
            <path
              d={`M ${cx} ${cy} L ${needleX} ${needleY}`}
              stroke="var(--accent)"
              strokeWidth={2}
              strokeLinecap="round"
            />
          </g>
        </PieChart>
        <div className="-mt-2 flex flex-col items-center gap-0.5">
          <span style={isBalanceVisible ? { color: 'var(--accent)' } : undefined}>
            <AnimatedNumber
              value={approvalRate}
              suffix="%"
              maximumFractionDigits={1}
              className={`text-2xl font-extrabold font-[family-name:var(--font-mono)] ${isBalanceVisible ? '' : 'visual-blur'}`}
            />
          </span>
          <span className={`text-[10px] font-bold uppercase ${isBalanceVisible ? '' : 'visual-blur'}`} style={{ color: 'var(--text-muted)' }}>
            {levelParse.label}
          </span>
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-[10px]" style={{ color: 'var(--text-muted)' }}>
          {GAUGE_SEGMENTS.map((seg) => (
            <div key={seg.name} className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full" style={{ backgroundColor: seg.color }} />
              <span>{seg.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
