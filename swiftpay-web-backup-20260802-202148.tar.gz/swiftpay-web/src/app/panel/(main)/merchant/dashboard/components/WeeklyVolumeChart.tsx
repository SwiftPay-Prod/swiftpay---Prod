'use client';

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from 'recharts';
import { AnalyticsUpIcon, InformationCircleIcon } from '@hugeicons/core-free-icons';
import { Icon } from '@/components/ui/icon';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { formatCurrency } from '@/utils/currency';
import type { MerchantWeeklyVolumeData } from '@/types/merchant/dashboard';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const ACCENT = 'hsl(var(--primary))';

const weeklyChartConfig = {
  volume: {
    label: 'Faturamento',
    color: ACCENT,
  },
} satisfies ChartConfig;

interface WeeklyVolumeChartProps {
  data: MerchantWeeklyVolumeData[];
  isHourlyGranularity: boolean;
  isProcessing?: boolean;
}

export function WeeklyVolumeChart({ data, isHourlyGranularity, isProcessing }: WeeklyVolumeChartProps) {
  const chartData = data.map((item) => ({
    week: item.label,
    volume: item.volume,
    transactionCount: item.transactionCount,
  }));

  return (
    <div className={`rounded-lg border bg-card text-card-foreground shadow-xs ${isProcessing ? 'opacity-70' : ''}`}>
      <div className="flex flex-col space-y-1.5 p-4 pb-0">
        <div className="flex items-center gap-2 text-sm font-medium leading-none">
          <Icon icon={AnalyticsUpIcon} className="icon-sm text-primary" />
          {isHourlyGranularity ? 'Evolução por hora' : 'Evolução diária'}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger className="inline-flex cursor-help">
                <Icon icon={InformationCircleIcon} className="icon-xs text-muted-foreground opacity-60" />
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-64 text-xs">
                Mostra a tendência do seu faturamento. A linha ajuda a visualizar se seus ganhos estão crescendo ou
                diminuindo.
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          {isProcessing && <div className="ml-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />}
        </div>
        <p className="text-xs text-muted-foreground">
          {isHourlyGranularity ? 'Últimas horas do período' : 'Período selecionado (agrupado por dia)'}
        </p>
      </div>
      <div className="p-4 pt-0">
        <ChartContainer config={weeklyChartConfig} className="h-32 w-full">
          <AreaChart accessibilityLayer data={chartData}>
            <defs>
              <linearGradient id="volumeGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={ACCENT} stopOpacity={0.3} />
                <stop offset="95%" stopColor={ACCENT} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} strokeDasharray="3 3" className="stroke-border/50" />
            <XAxis dataKey="week" tickLine={false} tickMargin={6} axisLine={false} fontSize={9} />
            <YAxis hide />
            <ChartTooltip content={<ChartTooltipContent formatter={(value) => formatCurrency(value as number)} />} />
            <Area type="monotone" dataKey="volume" stroke={ACCENT} strokeWidth={2} fill="url(#volumeGradient)" />
          </AreaChart>
        </ChartContainer>
      </div>
    </div>
  );
}
