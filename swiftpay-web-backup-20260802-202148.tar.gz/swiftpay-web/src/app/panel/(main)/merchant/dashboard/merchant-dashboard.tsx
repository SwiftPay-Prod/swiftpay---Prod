'use client';

import { useRouter } from 'next/navigation';
import { Select, ListBox, DateRangePicker, DateField, RangeCalendar } from '@heroui/react';
import {
	ArrowReloadHorizontalIcon,
	HelpCircleIcon,
	CalendarCheckIn01Icon,
	LiveStreaming02Icon,
	ViewIcon,
	ViewOffSlashIcon,
} from '@hugeicons/core-free-icons';
import { Icon } from '@/components/ui/icon';
import { PERIOD_OPTIONS, useMerchantDashboard } from '@/hooks/use-merchant-dashboard';
import { useDashboardLayout } from '@/hooks/use-dashboard-layout';
import { useBalanceVisibility } from '@/hooks/use-balance-visibility';
import type { ReadMerchantDashboardData, DashboardPeriod } from '@/types/merchant/dashboard';
import { formatRelativeTime } from '@/utils/datetime';
import { DashboardSkeleton } from './DashboardSkeleton';
import { MobileMerchantDashboard } from '@/components/panel/mobile-merchant-dashboard';
import { useIsMobile } from '@/hooks/use-is-mobile';
import { parseDate } from '@internationalized/date';
import { VolumeChart } from './components/VolumeChart';
import { WeeklyVolumeChart } from './components/WeeklyVolumeChart';
import { ApprovalRateGauge } from './components/ApprovalRateGauge';
import { MainKpiSection } from './components/MainKpiSection';
import { SecondaryKpiSection } from './components/SecondaryKpiSection';
import { DashboardLayoutPicker } from './components/DashboardLayoutPicker';
import { Routes } from '@/router/routes';

interface MerchantReserveConfig {
	pixReservePercentage: number;
	boletoReservePercentage: number;
	creditCardReservePercentage: number;
}

interface DashboardContentProps {
	dashboard: ReadMerchantDashboardData;
	onRefresh: () => void;
	isRefreshing: boolean;
	selectedPeriod: DashboardPeriod;
	onPeriodChange: (period: DashboardPeriod) => void;
	customStartDate: string;
	customEndDate: string;
	onCustomRangeChange: (startDate: string, endDate: string) => void;
	isBalanceVisible: boolean;
	onToggleBalanceVisibility: () => void;
	onOpenLiveScreen: () => void;
	hasReserveEnabled: boolean;
	reserveConfig: MerchantReserveConfig | null;
}

function DashboardContent({
	dashboard,
	onRefresh,
	isRefreshing,
	selectedPeriod,
	onPeriodChange,
	customStartDate,
	customEndDate,
	onCustomRangeChange,
	isBalanceVisible,
	onToggleBalanceVisibility,
	onOpenLiveScreen,
	hasReserveEnabled,
	reserveConfig,
}: DashboardContentProps) {
	const kpis = dashboard.kpis;
	const balance = dashboard.balance;
	const cacheInfo = dashboard.cacheInfo;
	const periodInfo = dashboard.periodInfo;
	const averageTicket = kpis.completedTransactions > 0 ? Math.round(kpis.totalVolume / kpis.completedTransactions) : 0;

	const { layout, changeLayout } = useDashboardLayout();

	const rangeValue =
		customStartDate && customEndDate ? { start: parseDate(customStartDate), end: parseDate(customEndDate) } : null;

	const periodDays = periodInfo
		? Math.max(
				1,
				Math.floor(
					(new Date(periodInfo.endDate).getTime() - new Date(periodInfo.startDate).getTime()) / (1000 * 60 * 60 * 24)
				) + 1
			)
		: 7;
	const isHourlyGranularity = periodDays <= 2;

	const weeklyChart = (
		<WeeklyVolumeChart
			data={dashboard.weeklyChart}
			isHourlyGranularity={isHourlyGranularity}
			isProcessing={cacheInfo.isProcessing}
		/>
	);

	const volumeChart = (
		<VolumeChart
			data={dashboard.volumeChart}
			adaptiveData={dashboard.weeklyChart}
			isHourlyGranularity={isHourlyGranularity}
			isProcessing={cacheInfo.isProcessing}
			periodLabel={periodInfo?.label}
		/>
	);

	const approvalGauge = (
		<ApprovalRateGauge
			approvalRate={kpis.approvalRate}
			approvalRateLevel={kpis.approvalRateLevel}
			isProcessing={cacheInfo.isProcessing}
			isBalanceVisible={isBalanceVisible}
		/>
	);

	const mainKpis = (
		<MainKpiSection
			kpis={kpis}
			balance={balance}
			cacheInfo={cacheInfo}
			averageTicket={averageTicket}
			isBalanceVisible={isBalanceVisible}
			hasReserveEnabled={hasReserveEnabled}
			reserveConfig={reserveConfig}
		/>
	);

	const secondaryKpis = (
		<SecondaryKpiSection kpis={kpis} cacheInfo={cacheInfo} isBalanceVisible={isBalanceVisible} />
	);

	function renderSections() {
		switch (layout) {
			case 'focus-charts':
				return (
					<>
						<div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
							{weeklyChart}
							{volumeChart}
						</div>
						{mainKpis}
						{secondaryKpis}
						{approvalGauge}
					</>
				);
			case 'focus-kpis':
				return (
					<>
						{mainKpis}
						{secondaryKpis}
						{weeklyChart}
						<div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
							{volumeChart}
							{approvalGauge}
						</div>
					</>
				);
			case 'compact':
				return (
					<>
						<div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
							<div className="lg:col-span-2">{weeklyChart}</div>
							{approvalGauge}
						</div>
						{mainKpis}
						{secondaryKpis}
						{volumeChart}
					</>
				);
			default:
				return (
					<>
						{weeklyChart}
						{mainKpis}
						{secondaryKpis}
						<div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
							{volumeChart}
							{approvalGauge}
						</div>
					</>
				);
		}
	}

	return (
		<div className="flex flex-col gap-4">
			<div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b pb-4" style={{ borderColor: 'var(--border)' }}>
				<div className="flex flex-wrap items-center gap-2">
					<Select
						variant="secondary"
						key={`period-select-${selectedPeriod}`}
						aria-label="Selecionar período"
						defaultValue={selectedPeriod}
						onChange={(key) => {
							if (key) onPeriodChange(key as DashboardPeriod);
						}}
						className="w-44"
					>
						<Select.Trigger>
							<Select.Value />
							<Select.Indicator />
						</Select.Trigger>
						<Select.Popover>
							<ListBox>
								{PERIOD_OPTIONS.map((opt) => (
									<ListBox.Item key={opt.key} id={opt.key} textValue={opt.label}>
										{opt.label}
										<ListBox.ItemIndicator />
									</ListBox.Item>
								))}
							</ListBox>
						</Select.Popover>
					</Select>

					{selectedPeriod === 'custom' && (
						<DateRangePicker
							value={rangeValue}
							onChange={(value) => {
								const nextStartDate = value?.start ? value.start.toString().slice(0, 10) : customStartDate;
								const nextEndDate = value?.end ? value.end.toString().slice(0, 10) : customEndDate;
								if (nextStartDate && nextEndDate) {
									onCustomRangeChange(nextStartDate, nextEndDate);
								}
							}}
						>
							<DateField.Group fullWidth variant="secondary" className="min-w-72">
								<DateField.Input slot="start">{(segment) => <DateField.Segment segment={segment} />}</DateField.Input>
								<DateRangePicker.RangeSeparator />
								<DateField.Input slot="end">{(segment) => <DateField.Segment segment={segment} />}</DateField.Input>
								<DateField.Suffix>
									<DateRangePicker.Trigger>
										<DateRangePicker.TriggerIndicator />
									</DateRangePicker.Trigger>
								</DateField.Suffix>
							</DateField.Group>
							<DateRangePicker.Popover>
								<RangeCalendar aria-label="Período personalizado" visibleDuration={{ months: 2 }}>
									<RangeCalendar.Header>
										<RangeCalendar.YearPickerTrigger>
											<RangeCalendar.YearPickerTriggerHeading />
											<RangeCalendar.YearPickerTriggerIndicator />
										</RangeCalendar.YearPickerTrigger>
										<RangeCalendar.NavButton slot="previous" />
										<RangeCalendar.NavButton slot="next" />
									</RangeCalendar.Header>
									<RangeCalendar.Grid>
										<RangeCalendar.GridHeader>
											{(day) => <RangeCalendar.HeaderCell>{day}</RangeCalendar.HeaderCell>}
										</RangeCalendar.GridHeader>
										<RangeCalendar.GridBody>{(date) => <RangeCalendar.Cell date={date} />}</RangeCalendar.GridBody>
									</RangeCalendar.Grid>
									<RangeCalendar.YearPickerGrid>
										<RangeCalendar.YearPickerGridBody>
											{({ year }) => <RangeCalendar.YearPickerCell year={year} />}
										</RangeCalendar.YearPickerGridBody>
									</RangeCalendar.YearPickerGrid>
								</RangeCalendar>
							</DateRangePicker.Popover>
						</DateRangePicker>
					)}

					{periodInfo && (
						<div className="flex items-center gap-1.5 rounded-[var(--radius)] px-2.5 py-1" style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}>
							<Icon icon={CalendarCheckIn01Icon} className="icon-xs" style={{ color: 'var(--accent)' }} />
							<span className="text-xs font-bold" style={{ color: 'var(--accent)' }}>{periodInfo.label}</span>
						</div>
					)}
				</div>

				<div className="flex items-center gap-3">
					<DashboardLayoutPicker layout={layout} onLayoutChange={changeLayout} />
					<button onClick={onToggleBalanceVisibility} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-[var(--radius)]" style={{ backgroundColor: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)' }}>
						<Icon icon={isBalanceVisible ? ViewOffSlashIcon : ViewIcon} className="icon-sm" />
						{isBalanceVisible ? 'Ofuscar' : 'Mostrar'}
					</button>
					<button onClick={onOpenLiveScreen} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-[var(--radius)]" style={{ backgroundColor: 'var(--bg)', border: '1px solid #ef4444', color: '#ef4444' }}>
						<Icon icon={LiveStreaming02Icon} className="icon-sm" />
						Live
					</button>
					{cacheInfo.isProcessing && (
          <div className="flex items-center gap-2 rounded-[var(--radius)] px-3 py-1" style={{ backgroundColor: 'rgba(245,158,11,0.1)', color: '#f59e0b' }}>
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-[#f59e0b] border-t-transparent" />
              <span className="text-xs font-bold" style={{ color: '#f59e0b' }}>Atualizando...</span>
            </div>
					)}
					{cacheInfo.lastUpdatedAt && (
						<div className="flex items-center gap-1.5">
							<span className="text-xs" style={{ color: 'var(--text-muted)' }}>Atualizado {formatRelativeTime(cacheInfo.lastUpdatedAt)}</span>
						</div>
					)}
					{!cacheInfo.lastUpdatedAt && !cacheInfo.isProcessing && (
						<span className="text-xs" style={{ color: 'var(--text-muted)' }}>Aguardando primeiro processamento...</span>
					)}
					<button onClick={onRefresh} disabled={isRefreshing} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-[var(--radius)] disabled:opacity-50" style={{ backgroundColor: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)' }}>
						<Icon icon={ArrowReloadHorizontalIcon} className="icon-sm" />
						Atualizar
					</button>
				</div>
			</div>

			{renderSections()}
		</div>
	);
}

interface MerchantDashboardProps {
	merchantId: string;
}

export function MerchantDashboard({ merchantId }: MerchantDashboardProps) {
	const isMobile = useIsMobile();
	const router = useRouter();
	const { data: hookData, period, actions } = useMerchantDashboard({ merchantId });
	const { isVisible: isBalanceVisible, toggle: toggleBalanceVisibility } = useBalanceVisibility();

	function openLiveBalanceRoute() {
		router.push(Routes.panel.merchant.liveBalance);
	}

	if (hookData.isLoading) {
		return <DashboardSkeleton />;
	}

  if (hookData.error) {
    return (
      <div className="rounded-[var(--radius)] p-4 text-sm" style={{ border: '1px solid #ef4444', backgroundColor: 'rgba(239,68,68,0.08)' }}>
        <p className="font-bold" style={{ color: '#ef4444' }}>Erro ao carregar dados</p>
        <p className="mt-1" style={{ color: 'var(--text-muted)' }}>{hookData.error}</p>
      </div>
    );
  }

  if (!hookData.dashboard) {
    return (
      <div className="rounded-[var(--radius)] p-4 text-sm" style={{ border: '1px solid #f59e0b', backgroundColor: 'rgba(245,158,11,0.08)' }}>
        <p className="font-bold" style={{ color: '#f59e0b' }}>Dados não disponíveis</p>
        <p className="mt-1" style={{ color: 'var(--text-muted)' }}>Não foi possível carregar os dados do dashboard.</p>
      </div>
    );
  }

	if (isMobile) {
		return (
			<MobileMerchantDashboard
				merchantId={merchantId}
				onOpenLiveScreen={openLiveBalanceRoute}
				isBalanceVisible={isBalanceVisible}
				onToggleBalanceVisibility={toggleBalanceVisibility}
				hasReserveEnabled={hookData.hasReserveEnabled}
			/>
		);
	}

	return (
		<DashboardContent
			dashboard={hookData.dashboard}
			onRefresh={actions.refresh}
			isRefreshing={hookData.isRefreshing}
			selectedPeriod={period.selected}
			onPeriodChange={period.change}
			customStartDate={period.customRange.startDate}
			customEndDate={period.customRange.endDate}
			onCustomRangeChange={period.setCustomRange}
			isBalanceVisible={isBalanceVisible}
			onToggleBalanceVisibility={toggleBalanceVisibility}
			onOpenLiveScreen={openLiveBalanceRoute}
			hasReserveEnabled={hookData.hasReserveEnabled}
			reserveConfig={hookData.reserveConfig}
		/>
	);
}
